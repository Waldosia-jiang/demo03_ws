Introduction
=====

ABC Swarm is an open source project short for Ant Bee Cooperative Swarm. This project aims to use low-cost  robots and drones to achieve multi-robot experiment sulotion without external positioning system. The overall objective of this framework is to support multi-robot coordination, air-ground cooperative swarm, formation control, ant colony optimization, wolf pack algorithm, distributed optimization, reinforcement deep learning, etc. 