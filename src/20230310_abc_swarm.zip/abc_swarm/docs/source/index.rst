ABC Swarm documentation
===================================

**ABC Swarm** Ant-Bee-Cooperative Swarm, indicating air-ground multi-robot cooperation. This project is developed for ROS2GO, Tianbot Mini and RoboMaster TT swarm kit.

.. note::

   This project is under active development.

Contents
--------

.. toctree::

   intro
   ros2go
   tbmn
   rmtt
   simulation
   algorithm
   two_robots
   two_drones




